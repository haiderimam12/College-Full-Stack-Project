<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Portal</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.4.0/fonts/remixicon.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil:opsz,wght@10..72,100..900&display=swap"
        rel="stylesheet">
    <style>
        * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: "Big Shoulders Stencil", sans-serif;
            font-optical-sizing: auto;
        }

        html,
        body {
            height: 100%;
            width: 100%;
        }

        /* ---------------------- Navbar ---------------------- */

        nav {
            height: 5rem;
            width: 100%;
            background-color: rgba(0, 0, 0, 0.921);
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            justify-content: space-evenly;
        }

        nav .logo p {
            font-size: 2rem;
            color: white;
        }

        nav .logo h5 {
            font-weight: lighter;
            text-align: center;
            color: gainsboro;
        }

        nav ul {
            display: flex;
            gap: 3rem;
        }

        nav ul li {
            list-style: none;
        }

        nav ul li a {
            font-size: 1.2rem;
            color: rgb(197, 193, 193);
            text-decoration: none;
            transition: all ease 0.5s;
            border-bottom: 1px solid white;
            padding: 1vh 1.5vw;
            border-radius: 8px;
        }

        nav ul li a:hover {
            color: #FF9635;
            border-color: #FF9635;
        }

        a button {
            text-transform: uppercase;
            font-size: 1.2rem;
            border: 0;
            outline: 0;
            color: #fff;
            cursor: pointer;
            transition: all ease 0.5s;
            border-radius: 20px;
            padding: 1vh 2vw;
            background-color: #FF9635;
        }

        a button:hover {
            background-color: transparent;
        }

        /* ---------------------- Home-1 ---------------------- */

        .home-1 {
            background-color: black;
            height: 350vh;
            width: 100%;
            text-align: center;
        }

        .home-1 .head-topic-1 {
            position: relative;
            left: 10%;
            top: 50px;
            padding: 2vh;
            height: 70vh;
            width: 80%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background-color: #1d1d1d67;
            backdrop-filter: blur(2px);
            box-shadow: 1px 1px 10px rgb(119, 119, 119);
        }

        .home-1 .head-topic-1 .head-topic-child-1 {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            width: 480px;
        }

        .home-1 .head-topic-1 .head-topic-child-1 h3 {
            background-color: #4d4c4c;
            border-radius: 4px;
            color: white;
            padding: 1vh;
        }

        .home-1 .head-topic-1 h2 {
            font-size: 2rem;
            color: white;
        }

        .home-1 .head-topic-1 h2 span {
            color: #ff9635;
        }

        .home-1 .head-topic-1 h1 {
            font-size: 3rem;
            color: white;
        }

        a button {
            text-transform: uppercase;
            font-size: 1.2rem;
            border: 0;
            outline: 0;
            color: #fff;
            cursor: pointer;
            transition: all ease 0.5s;
            border-radius: 20px;
            padding: 1vh 2vw;
            background-color: #FF9635;
        }

        a button:hover {
            background-color: #f3841d;
        }

        .home-1 p {
            font-size: 2rem;
            color: white;
        }

        .home-1 .head-topic-2 {
            height: 130vh;
        }

        .home-1 .head-topic-2 .img {
            padding-top: 20vh;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-evenly;
            gap: 1rem;
        }

        .home-1 .head-topic-2 .mongodb {
            filter: drop-shadow(0px 0px 100px rgb(3, 247, 3));
            height: 250px;
        }

        .home-1 .head-topic-2 .exp {
            filter: drop-shadow(0px 0px 100px grey);
            height: 250px;
        }

        .home-1 .head-topic-2 .js {
            filter: drop-shadow(0px 0px 100px gold);
            height: 250px;
        }

        .home-1 .head-topic-2 .node {
            filter: drop-shadow(0px 0px 100px yellowgreen);
            height: 250px;
        }

        .home-1 .head-topic-2 h1 {
            padding-top: 10vh;
            color: gainsboro;
            font-size: 10rem;
        }

        .home-1 .head-topic-2 p {
            font-weight: 200;
        }

        .home-1 .head-topic-3 {
            position: relative;
            left: 10%;
            line-height: 6vh;
            width: 80%;
            padding: 3vh;
            background-color: #1d1d1d;
            backdrop-filter: blur(10px);
            box-shadow: 1px 1px 10px rgb(119, 119, 119);
            height: 140vh;
        }

        .head-topic-3 h1 {
            text-align: start;
            font-size: 3rem;
            color: white;
        }

        .head-topic-3 h1 span {
            font-weight: lighter;
            color: #ff9635;
            text-align: center;
        }

        .head-topic-3 video {
            height: 340px;
        }

        /* ---------------------- Home-5 ---------------------- */

        .home-5 {
            height: 100vh;
            width: 100%;
        }

        .home-5 .header {
            height: 50%;
            width: 100%;
            background-color: #ebeff1;
            padding-top: 10vh;
        }

        .header h2 {
            text-align: center;
            font-size: 3rem;
        }

        .header p {
            text-align: center;
            color: #22323d;
        }

        .header form {
            margin-left: 35vw;
            margin-top: 3vh;
            display: flex;
            gap: 1rem;
        }

        .header input {
            font-size: 1.2rem;
            border: 0.9 solid black;
            width: 22vw;
            outline: 0;
            padding: 1vh 1vw;
        }

        .header .sub {
            color: white;
            padding: 1vw 2vw;
            font-size: 1.3rem;
            border-radius: 50px;
            border: 0;
            outline: 0;
            background-color: #ff9635;
            transition: all ease 0.5s;
            cursor: pointer;
        }

        .header .sub:hover {
            background-color: #041979d7;
        }

        ::placeholder {
            font-size: 1.2rem;
        }

        .home-5 .footer {
            height: 50%;
            width: 100%;
            background-color: #fff;
            padding-top: 6vh;
        }

        .footer-logo {
            text-align: center;
            width: 9vw;
        }

        .footer-logo p {
            font-size: 2.5rem;
        }

        .footer-logo h5 {
            font-size: 1rem;
        }

        .footer-logo h5 {
            font-weight: lighter;
            text-align: center;
            color: #22323d;
        }

        .footer .box {
            display: flex;
            align-items: center;
            margin-left: 10vw;
            gap: 4rem;
        }

        .footer .box-1 {
            padding: 5vh 2vw;
            height: 250px;
            width: 600px;
        }

        .footer .box-1 p {
            color: #22323d;
        }

        .footer .icons {
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .footer .icons a {
            text-decoration: none;
            color: black;
            font-size: 1.5rem;
        }

        .footer .icons .ri-facebook-circle-fill {
            transition: all ease 0.5s;
        }

        .footer .icons .ri-twitter-fill {
            transition: all ease 0.5s;
        }

        .footer .icons .ri-pinterest-fill {
            transition: all ease 0.5s;
        }

        .footer .icons .ri-youtube-fill {
            transition: all ease 0.5s;
        }

        .footer .icons .ri-facebook-circle-fill:hover {
            color: blue;
        }

        .footer .icons .ri-twitter-fill:hover {
            color: blue;
        }

        .footer .icons .ri-pinterest-fill:hover {
            color: red;
        }

        .footer .icons .ri-youtube-fill:hover {
            color: red;
        }

        .footer .box-2 {
            line-height: 3vh;
            margin-top: 2vh;
            height: 200px;
            padding: 1vh 0.8vw;
        }

        .footer .box-2 a {
            text-decoration: none;
            color: black;
            transition: all ease 0.5s;
            font-size: 1rem;
        }

        .footer .box-2 a:hover {
            color: #ff9635;
        }

        .footer .head-last {
            font-size: 2rem;
            color: #22323d;
        }

        .footer .box-2 p {
            color: #22323d;
        }

        .footer .box-3 {
            margin-top: 1vh;
            height: 200px;
            padding: 1vh 0.8vw;
            line-height: 3vh;
        }
    </style>
</head>

<body>

    <!-------------------------------- Navbar  -------------------------------->

    <div class="home">
        <nav>
            <div class="logo">
                <p>-|LearniX|-</p>
                <h5>The Page To The Future</h5>
            </div>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="course.html">All Courses</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="pricing & faq.html">Pricing & FAQ</a></li>
            </ul>
            <div class="button">
                <a href="signup.php"><button>Start Learning</button></a>
            </div>
        </nav>
    </div>

    <!-------------------------------- Home-1 -------------------------------->

    <div class="home-1">
        <div class="head-topic-1">
            <h1>Back-end Domination - Create <br> Anything With Code</h1>
            <br>
            <div class="head-topic-child-1">
                <h3>Backend Development 👨‍💻</h3>
                <h3>Logic Building 👨‍💻</h3>
            </div>
            <br>
            <h2>Only <span>₹8000</span></h2>
            <br>
            <a href="#"><button>Buy Now - Start Learning</button></a>
            <br>
            <br>
            <p>Ready to rule the digital world? Learn to build powerful back-ends that drive website and apps smoothly.
                From databases to security, we cover it all.</p>
        </div>
        <div class="head-topic-2">
            <div class="img">
                <img class="mongodb" src="icons/mon-pp.png" alt="">
                <img class="exp" src="icons/exp-pp.png" alt="">
                <img class="js" src="icons/js2.png" alt="">
                <img class="node" src="icons/node-pp.png" alt="">
            </div>
            <br>
            <h1>Project Which Matters</h1>
            <p>Beyond Projects, Towards Purpose .</p>
        </div>
        <div class="head-topic-3">
            <h1>Project 1 - <span>Avatar Generate API</span>
            </h1>
            <br>
            <video autoplay loop muted src="icons/project-pp/Avataranimation_UGIZk1sWT.webm"></video>
            <br>
            <br>
            <h1>Project 2 - <span>Secures & Blazingly Fast Video Streaming WebApp-Devtube</span>
            </h1>
            <br>
            <video autoplay loop muted src="icons/project-pp/Devtubeanimation_1WdWD8HBL.webm"></video>
        </div>
    </div>

    <!-------------------------------- Home-5 -------------------------------->

    <div class="home-5">
        <div class="header">
            <h2>Join Our Community</h2>
            <br>
            <p>Enter your email address to register to our newsletter subscription delivered on regular basis!</p>
            <br>
            <form action="#">
                <input type="email" placeholder="Enter your email" required autocomplete="off">
                <button class="sub">Subscribe</button>
            </form>
        </div>
        <div class="footer">
            <div class="box">
                <div class="box-1">
                    <div class="footer-logo">
                        <p>-|LearniX|-</p>
                        <h5>The Page To The Future</h5>
                    </div>
                    <br>
                    <p>Empowering learners everywhere. Whether you're upgrading your skills, exploring new interests, or
                        preparing for your career, our e-learning platform is here to support your journey. Learn at
                        your own pace, anytime, anywhere. Join us and unlock your potential today!</p>
                    <br>
                    <div class="icons">
                        <p><a href="#"><i class="ri-facebook-circle-fill"></i></a></p>
                        <p><a href="#"><i class="ri-twitter-fill"></i></a></p>
                        <p><a href="#"><i class="ri-pinterest-fill"></i></a></p>
                        <p><a href="#"><i class="ri-youtube-fill"></i></a></p>
                    </div>
                </div>
                <div class="box-2">
                    <h2 class="head-last">Popular Courses</h2>
                    <br>
                    <p><a href="#">LMS Interactive Content</a></p>
                    <p><a href="#">Become a PHP Master</a></p>
                    <p><a href="#">HTML5/CSS3 Essentials</a></p>
                    <p><a href="#">JavaScript Development</a></p>
                    <p><a href="#">WordPress Basic Tutorial</a></p>
                    <p><a href="#">Introduction to Coding</a></p>
                </div>
                <div class="box-3">
                    <h2 class="head-last">Contact Info</h2>
                    <br>
                    <h3>Address</h3>
                    <p>123 Fifth Avenue, New York, NY 10160</p>
                    <h3>Phone</h3>
                    <p>8604-381-910</p>
                    <h3>Email</h3>
                    <p>contact@info.com</p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://unpkg.com/lenis@1.1.16/dist/lenis.min.js"></script>
    <script>
        const lenis = new Lenis();

        function raf(time) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }

        requestAnimationFrame(raf);
    </script>
</body>

</html>