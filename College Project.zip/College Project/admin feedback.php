<?php 

if (isset($_POST['submit'])) 
{
    $admin_id = $_POST['admin_id'];
    $password = $_POST['password'];

    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $dbname = 'database';

    $conn = mysqli_connect($host,$user,$pass,$dbname);

    $sql = "INSERT INTO admin_feedback(admin_id,password) values('$admin_id','$password')";

    mysqli_query($conn,$sql);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Feedback - LearniX</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil:opsz,wght@10..72,100..900&display=swap"
        rel="stylesheet">
    <style>
        * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: "Big Shoulders Stencil", sans-serif;
            font-optical-sizing: auto;        
        }

        html,
        body {
            height: 100%;
            width: 100%;
            background: url(https://c0.wallpaperflare.com/path/811/935/645/adults-analysis-brainstorming-collaboration-2dbc2313ebbbdc95ae58afc59dc38d7f.jpg);
            background-size: cover;
            background-position: center;
        }

        .container {
            height: 100%;
            width: 100%;
            background-color: #1d1d1dd1;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .left-container-1 {
            height: 100%;
            width: 40%;
            padding-top: 35vh;
            padding-left: 5vw;
        }

        .left-container-1 h1 {
            box-shadow: 0px 0px 30px rgb(83, 80, 80);
            text-shadow: -10px 0px 4px rgb(48, 48, 48);
            text-align: center;
            color: #f68e2d;
            background-color: #1d1d1daa;
            border-radius: 10px;
            backdrop-filter: blur(10px);
            font-size: 10rem;
            width: 700px;
        }

        .right-container-1 {
            padding-top: 10vh;
            padding-left: 15vw;
            width: 60%;
            height: 100vh;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-evenly;
            border: 1px solid rgb(92, 91, 91);
            margin-top: 10px;
            background-color: #e48a36b3;
            box-shadow: 0px 0px 30px rgb(148, 147, 147);
            padding: 0vh 6vw;
            border-radius: 10px;
            height: 600px;
            width: 440px;
        }

        form .return-home-page {
            text-decoration: none;
            color: white;
            margin-left: 25vw;
            font-size: 1.5rem;
        }

        form .top-h1 {
            text-align: center;
            color: white;
            font-size: 2.2rem;
            width: 260px;
        }
        
        form h2 {
            text-align: center;
            color: white;
            font-size: 1.5rem;
            width: 260px;
        }

        input {
            background: rgb(224, 223, 223);
            width: 312px;
            border-radius: 5px;
            border: 0;
            outline: 0;
            text-align: start;
            font-size: 1rem;
            padding: 1.2vh;
        }

        form .btn {
            display: flex;
        }

        form button {
            cursor: pointer;
            width: 150px;
            gap: 1rem;
            margin: 4vh 0.4vw;
            font-weight: bold;
            border-radius: 5px;
            padding: 0.8vh 0vw;
            border: 0;
            outline: 0;
            font-size: 1.2rem;
        }

        form p {
            cursor: pointer;
            color: white;
            width: 260px;
            font-size: 1.1rem;
            text-align: center;
        }
        
        form p a {
            transition: all ease 0.3s;
            text-decoration: none;
            cursor: pointer;
            color: white;
            width: 260px;
            font-size: 1.1rem;
            text-align: center;
        }

        form p a:hover{
            color: #f68e2d;
        }

    </style>
</head>

<body>
    <!----------------------------- Login Form ----------------------------->

    <div class="container">
        <div class="left-container-1">
            <h1>LearniX</h1>
        </div>
        <div class="right-container-1">
            <form action="#" method="POST">
                <a href="index.html" class="return-home-page"><i class="ri-close-fill"></i></a>
                <h1 class="top-h1">Admin Panel</h1>
                <br>
                <input name="admin_id" type="text" placeholder="admin id" required>
                <input name="password" type="password" placeholder="password" required>
                <h2>See Feedback Details</h2>
                <div class="btn">
                    <a href="#"><button name="submit" type="submit">Login</button></a>
                </div>
                <br>
                <p>
                    <a href="admin reg user.php">User Details</a> /
                    <a href="admin feedback.php">Feedback Details</a> /
                    <a href="admin contact.php">Contact Details</a>
                </p>
            </form>
        </div>
    </div>

</body>

</html>