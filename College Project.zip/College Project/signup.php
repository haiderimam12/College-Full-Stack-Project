<?php 

if (isset($_POST['submit'])) 
{
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $password = $_POST['password'];

    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $dbname = 'database';

    $conn = mysqli_connect($host,$user,$pass,$dbname);

    $sql = "INSERT INTO user_reg(first_name,last_name,email,phone_number,password) values('$first_name','$last_name','$email','$phone_number','$password')";

    mysqli_query($conn,$sql);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - LearniX</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css"
    rel="stylesheet"
/>
<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil:opsz,wght@10..72,100..900&display=swap"
        rel="stylesheet">
    <style>
        * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: "Big Shoulders Stencil", sans-serif;
            font-optical-sizing: auto;        }

        html,
        body {
            height: 100%;
            width: 100%;
            background: url(https://c0.wallpaperflare.com/path/811/935/645/adults-analysis-brainstorming-collaboration-2dbc2313ebbbdc95ae58afc59dc38d7f.jpg);
            background-size: cover;
            background-position: center;
        }

        .container {
            height: 100%;
            width: 100%;
            background-color: #1d1d1dd1;
            display: flex;
        }

        .container .left-container-1 {
            height: 100%;
            width: 40%;
            padding-top: 35vh;
            padding-left: 5vw;
        }

        .container .left-container-1 h1 {
            text-shadow: -10px 0px 4px rgb(37, 37, 37);
            text-align: center;
            color: #fba452;
            background-color: rgba(216, 215, 215, 0.338);
            border-radius: 10px;
            backdrop-filter: blur(10px);
            font-size: 10rem;
            width: 700px;
        }

        .container .right-container-1 {
            padding-top: 6vh;
            padding-left: 15vw;
            width: 60%;
            height: 100vh;
        }

        .container .right-container-1 .heading {
            width: 440px;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
        }

        .container .right-container-1 .heading a {
            font-weight: bold;
            border-radius: 20px;
            font-size: 1.3rem;
            text-decoration: none;
            color: white;
        }

        .container .right-container-1 .heading .li-btn {
            padding: .8vh;
            width: 50%;
            background-color: #1d1d1d;
            transition: all ease 0.3s;
        }

        .container .right-container-1 .heading .su-btn {
            background-color: rgba(180, 178, 178, 0.725);
            padding: .8vh;
            width: 50%;
            transition: all ease 0.3s;
        }

        .container form {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-evenly;
            border: 1px solid rgb(72, 72, 72);
            margin-top: 10px;
            background-color: rgba(180, 178, 178, 0.725);
            padding: 5vh 6vw;
            border-radius: 10px;
            height: 600px;
            width: 440px;
        }

        form .return-home-page{
            text-decoration: none;
            color: white;
            margin-left: 25vw;
            margin-top: -4.5vh;
            font-size: 1.5rem;
        }

        .container form .top-p {
            color: white;
            font-size: 1.2rem;
            width: 200px;
        }

        .container form .top-p a {
            font-size: 1.5rem;
            font-weight: 600;
            text-decoration: none;
            transition: all ease 0.3s;
            color: #2b1ae2;
        }

        .container form .top-p a:hover {
            color: #1b0eab;
        }

        .container form .or {
            cursor: none;
            font-size: 1.5rem;
            color: rgb(49, 49, 49);
        }

        form input {
            background: rgb(224, 223, 223);
            width: 230px;
            border-radius: 5px;
            border: 0;
            outline: 0;
            margin: 1vh;
            text-align: start;
            font-size: 1rem;
            padding: 1.2vh;
        }

        form button {
            cursor: pointer;
            width: 230px;
            margin-top: 4vh;
            font-weight: bold;
            border-radius: 5px;
            padding: 0.8vh 0vw;
            border: 0;
            outline: 0;
            font-size: 1.2rem;
        }

        form p {
            cursor: pointer;
            width: 260px;
            font-size: 1.1rem;
            color: #201c1c;
            text-align: center;
        }

        form p strong {
            color: #1d1d1d;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="left-container-1">
            <h1>LearniX</h1>
        </div>
        <div class="right-container-1">
            <div class="heading">
                <a class="su-btn" href="signup.php">SIGN UP</a>
                <a class="li-btn" href="login.php">LOGIN</a>
            </div>
            <form action="#" method="POST">
                <a href="index.html" class="return-home-page"><i class="ri-close-fill"></i></a>
                <p class="top-p">Already have an account? <br><a href="login.php">LOGIN</a></p>
                <br>
                <p class="or">OR</p>
                <br>
                <input name="first_name" type="text" placeholder="first name" required>
                <input name="last_name" type="text" placeholder="last name" required>
                <input name="email" type="email" placeholder="email" required>
                <input name="phone_number" type="tel" placeholder="phone number" required>
                <input name="password" type="password" placeholder="password" required>
                <a href="#"><button name="submit" type="submit">Sign Up</button></a>
                <br>
                <p>By signing up you agree to our <strong>Terms of Service</strong> and <strong>Privacy Policy</strong>.
                </p>
            </form>
        </div>
    </div>
</body>

</html>